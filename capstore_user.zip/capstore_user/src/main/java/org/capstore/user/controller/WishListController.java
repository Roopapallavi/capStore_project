package org.capstore.user.controller;

import java.util.HashMap;
import java.util.Map;

import org.capstore.user.model.Customer;
import org.capstore.user.model.WishList;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

public class WishListController {

	
	@RequestMapping("/wishList/{customerId}")
	public String getWishListPage(@PathVariable ("customerId") Integer customerId, ModelMap map) {
		final String uri="http://localhost:8081/capstoreApp/CapStore/WishList//wishLists/{custId}";
		RestTemplate restTemplate=new RestTemplate();
		Map<String,Object> params=new HashMap<>();
		params.put("customerId", customerId);
		
		WishList[] wishList= restTemplate.getForObject(uri, WishList[].class,params);
		
		
		map.put("wishList",wishList);
		map.put("WishList", new WishList());
		
		return "WishList_full";
		
	}
}
