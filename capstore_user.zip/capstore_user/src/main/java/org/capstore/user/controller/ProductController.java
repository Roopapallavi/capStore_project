package org.capstore.user.controller;

import java.util.HashMap;
import java.util.Map;

import org.capstore.user.model.Inventory;
import org.capstore.user.model.WishList;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

public class ProductController {

	
	
	@RequestMapping("/prods")
	public String ProductPage(@PathVariable ("productId") Integer productId, ModelMap map){
		final String uri="http://localhost:8081/capstoreApp/api/v2/prods";
		RestTemplate restTemplate=new RestTemplate();
		Map<String,Object> params=new HashMap<>();
		params.put("productId", productId);
		
		Inventory[] inventory= restTemplate.getForObject(uri, Inventory[].class,params);
		
		map.put("inventory",inventory);
		map.put("Inventory", new Inventory());
		
		return "Product_full";	
		
	}
	
	
}
